#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[] ){
	char line[9999];

FILE *fp = fopen(argv[1], "r");
if (fp == NULL){
	printf("File is empty\n");
	return 0;
}
else{
	while(fgets(line, 9999, fp) != NULL){
		if(strstr(line, argv[2])){
			puts(line);

		}	
	}
}
fclose(fp);
return 0;
}
