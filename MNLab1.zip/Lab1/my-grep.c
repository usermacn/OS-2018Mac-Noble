#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[] ){
	char line[9999];
	int key = 1;
for (int i = 2; i<=argc-1; i++){
FILE *fp = fopen(argv[i], "r");
 if (fp == NULL){
	printf("my-grep: cannot open file\n");
	return 0;
}
 
else{
	while(fgets(line, 9999, fp) != NULL){
		if(strstr(line, argv[key])){
			puts(line);

		}	 
	}
}
fclose(fp);
return 0;
}
}
