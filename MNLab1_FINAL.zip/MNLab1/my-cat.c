// Including Standard Input Output Library
#include <stdio.h>

int main(int argc, char *argv[] ){
	char line[9999];				// array to store lines of the textfile read
									// loop that iterates while the number of input parameters is greater than 1
for (int i=1; i<= argc-1; i++){
	FILE *fp = fopen(argv[i], "r"); // declaring a file pointer i for reading
		if (fp == NULL){ 			// error checking condition
			printf("File is empty\n");
			return 0;
			   }
		else{
			while(fgets(line, 9999, fp) != NULL){ // writing to screen
				printf("%s\n",line );
	}
}

fclose(fp); 						// closing initially opened file
}
return 0;
}


								