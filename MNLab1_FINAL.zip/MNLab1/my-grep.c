#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[] ){
	char line[9999];			// array to store lines of the textfile read
	char userinput[9999];		// array to store standard input the user inputs
	int key = 1;
for (int i = 2; i<=argc-1; i++) // loop that iterates while the number of input parameters is greater than 1
{
	FILE *fp = fopen(argv[i], "r"); // declaring a file pointer i for reading
	 if (fp == NULL){				// error checking condition
		printf("my-grep: cannot open file\n");
		return 0;
}

else{
	while(fgets(line, 9999, fp) != NULL){ // searching for key term between line and string stored in array argv
		if(strstr(line, argv[key])){
			puts(line);                   //printing to scrren

		}	 
	}
}
fclose(fp);} // closing file
if (argc < 3)
{
	fgets(userinput, 9999, stdin); // taking user inut and matching with input entered 
	if(strstr(userinput, argv[1]))
	{
			puts(userinput);
	}

}
return 0;
}
